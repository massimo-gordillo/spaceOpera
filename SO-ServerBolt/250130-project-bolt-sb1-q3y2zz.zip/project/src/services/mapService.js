import { supabase } from '../config/supabase.js';

export class MapService {
  async saveMap({ name, width, height, tiles, pieces }) {
    try {
      // Start a Supabase transaction
      const { data: map, error: mapError } = await supabase
        .from('maps')
        .insert({
          name,
          width,
          height
        })
        .select()
        .single();

      if (mapError) throw mapError;

      // Insert tiles
      const tilePromises = tiles.map((tileType, index) => {
        const x = index % width;
        const y = Math.floor(index / width);
        return supabase.rpc('add_map_tile', {
          p_map_id: map.id,
          p_x_loc: x,
          p_y_loc: y,
          p_tile_type: tileType
        });
      });

      // Insert pieces
      const piecePromises = pieces.map(piece => 
        supabase.rpc('add_map_init_piece', {
          p_map_id: map.id,
          p_piece_type: piece.isUnit,
          p_x_loc: piece.x,
          p_y_loc: piece.y,
          p_type_num: piece.typeId,
          p_player_controller: piece.ownerId,
          p_health_val: piece.health
        })
      );

      // Wait for all inserts to complete
      const [tileResults, pieceResults] = await Promise.all([
        Promise.all(tilePromises),
        Promise.all(piecePromises)
      ]);

      // Check for errors
      const tileErrors = tileResults.filter(result => result.error);
      const pieceErrors = pieceResults.filter(result => result.error);

      if (tileErrors.length > 0 || pieceErrors.length > 0) {
        throw new Error('Failed to insert all map data');
      }

      return map;
    } catch (error) {
      console.error('Error saving map:', error);
      throw error;
    }
  }

  async getMap(mapId) {
    try {
      // Get basic map info
      const { data: map, error: mapError } = await supabase
        .from('maps')
        .select()
        .eq('id', mapId)
        .single();

      if (mapError) throw mapError;

      // Get tiles
      const { data: tiles, error: tilesError } = await supabase
        .from('map_tiles')
        .select('x_loc, y_loc, tile_type')
        .eq('map_id', mapId);

      if (tilesError) throw tilesError;

      // Get pieces
      const { data: pieces, error: piecesError } = await supabase
        .from('map_init_pieces')
        .select('piece_type, x_loc, y_loc, type_num, player_controller, health_val')
        .eq('map_id', mapId);

      if (piecesError) throw piecesError;

      // Convert tiles to 2D array
      const tileGrid = Array(map.height).fill(null)
        .map(() => Array(map.width).fill(0));
      
      tiles.forEach(tile => {
        tileGrid[tile.y_loc][tile.x_loc] = tile.tile_type;
      });

      // Format pieces
      const formattedPieces = pieces.map(piece => ({
        isUnit: piece.piece_type,
        x: piece.x_loc,
        y: piece.y_loc,
        typeId: piece.type_num,
        ownerId: piece.player_controller,
        health: piece.health_val
      }));

      return {
        ...map,
        tiles: tileGrid,
        pieces: formattedPieces
      };
    } catch (error) {
      console.error('Error getting map:', error);
      throw error;
    }
  }

  async listMaps() {
    const { data, error } = await supabase
      .from('maps')
      .select()
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }
}