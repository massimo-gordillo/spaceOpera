import express from 'express';
import { MapService } from '../services/mapService.js';

const router = express.Router();
const mapService = new MapService();

// Submit new map
router.post('/', async (req, res) => {
  try {
    const { name, tiles, width, height, pieces } = req.body;
    
    // Validate input
    if (!Array.isArray(tiles) || tiles.length !== width * height) {
      throw new Error('Invalid tiles data: must be an array matching width * height');
    }

    if (!Array.isArray(pieces)) {
      throw new Error('Invalid pieces data: must be an array');
    }

    // Validate pieces
    pieces.forEach(piece => {
      if (
        typeof piece.x !== 'number' ||
        typeof piece.y !== 'number' ||
        typeof piece.typeId !== 'number' ||
        typeof piece.ownerId !== 'number' ||
        typeof piece.health !== 'number' ||
        typeof piece.isUnit !== 'boolean' ||
        piece.x < 0 || piece.x >= width ||
        piece.y < 0 || piece.y >= height
      ) {
        throw new Error('Invalid piece data format');
      }
    });
    
    const map = await mapService.saveMap({
      name,
      width,
      height,
      tiles,
      pieces
    });
    
    res.json(map);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get specific map
router.get('/:id', async (req, res) => {
  try {
    const map = await mapService.getMap(req.params.id);
    res.json(map);
  } catch (error) {
    res.status(404).json({ error: 'Map not found' });
  }
});

// List all maps
router.get('/', async (req, res) => {
  try {
    const maps = await mapService.listMaps();
    res.json(maps);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;