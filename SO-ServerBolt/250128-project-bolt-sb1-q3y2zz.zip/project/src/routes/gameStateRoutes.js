import express from 'express';
import { GameService } from '../services/gameService.js';

const router = express.Router();
const gameService = new GameService();

// Create a new match
router.post('/matches', async (req, res) => {
  try {
    const { playerAId, playerBId, mapId } = req.body;
    const match = await gameService.createMatch(playerAId, playerBId, mapId);
    res.json(match);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Submit a turn
router.post('/submit-turn', async (req, res) => {
  try {
    const { gameId, playerId, actions, finalStateHash, previousStateHash } = req.body;
    await gameService.submitTurn(gameId, playerId, actions, finalStateHash, previousStateHash);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;