import express from 'express';
import { MapService } from '../services/mapService.js';

const router = express.Router();
const mapService = new MapService();

// Submit new map
router.post('/', async (req, res) => {
  try {
    const mapData = {
      name: req.body.name,
      gridData: Buffer.from(req.body.gridData, 'base64'),
      width: req.body.width,
      height: req.body.height,
      initPieceData: Buffer.from(req.body.initPieceData, 'base64'),
      compressionMethod: req.body.compressionMethod
    };
    
    const map = await mapService.saveMap(mapData);
    res.json(map);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get specific map
router.get('/:id', async (req, res) => {
  try {
    const map = await mapService.getMap(req.params.id);
    res.json(map);
  } catch (error) {
    res.status(404).json({ error: 'Map not found' });
  }
});

// List all maps
router.get('/', async (req, res) => {
  try {
    const maps = await mapService.listMaps();
    res.json(maps);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;