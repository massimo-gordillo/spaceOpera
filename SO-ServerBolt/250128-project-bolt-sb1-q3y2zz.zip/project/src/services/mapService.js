import { supabase } from '../config/supabase.js';

export class MapService {
  async saveMap(mapData) {
    const { data, error } = await supabase
      .from('maps')
      .insert({
        name: mapData.name,
        grid_data: mapData.gridData,
        width: mapData.width,
        height: mapData.height,
        init_piece_data: mapData.initPieceData,
        compression_method: mapData.compressionMethod
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getMap(mapId) {
    const { data, error } = await supabase
      .from('maps')
      .select()
      .eq('id', mapId)
      .single();

    if (error) throw error;
    return data;
  }

  async listMaps() {
    const { data, error } = await supabase
      .from('maps')
      .select()
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }
}