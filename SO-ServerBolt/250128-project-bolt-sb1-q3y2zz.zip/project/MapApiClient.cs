using UnityEngine;
using UnityEngine.Networking;
using System;
using System.Threading.Tasks;

public class MapApiClient : MonoBehaviour
{
    private const string BaseUrl = "http://localhost:3000"; // Change this to your actual server URL
    
    public async Task<MatchData> CreateMatchAsync(string playerAId, string playerBId, string mapId)
    {
        try
        {
            // Define the endpoint for creating a match
            string endpoint = $"{BaseUrl}/game/matches";

            // Prepare the request data
            var requestData = new
            {
                playerAId,
                playerBId,
                mapId
            };

            // Use the generic SendRequest method to call the server
            MatchData match = await SupabaseClient.Instance.Functions.Invoke<MatchData>(
                endpoint,
                requestData,
                new Supabase.Functions.FunctionsRequestOptions { Method = HttpMethod.Post }
            );
            
            Debug.Log("Match created successfully.");
            return match;
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error creating match: {ex.Message}");
            throw;
        }
    }
    
    // Test connection to the server
    public async Task<bool> PingServer()
    {
        try
        {
            using var request = UnityWebRequest.Get($"{BaseUrl}/health");
            var operation = request.SendWebRequest();
            
            while (!operation.isDone)
                await Task.Yield();

            if (request.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("Server connection successful!");
                return true;
            }
            else
            {
                Debug.LogError($"Server connection failed: {request.error}");
                return false;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error connecting to server: {ex.Message}");
            return false;
        }
    }
}